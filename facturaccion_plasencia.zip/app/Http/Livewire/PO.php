<?php

namespace App\Http\Livewire;
use Livewire\Component;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\DB;
use App\Imports\POimport;
use Carbon\Carbon;
use Exception;


class PO extends Component
{

    public $Po;
    public $b_item;

    public $b_orden;

    public $b_marca;
    public $b_nombre;
    public $b_vitola;
    public $b_capa;
    public $b_tipo_empaque;

    public $hondelete;

    public function render(Request $request)
    {
        $this->Po = DB::table('po')
        ->join('clase_productos', 'clase_productos.item', 'po.item')
        ->join('marca_productos', 'marca_productos.id_marca', 'clase_productos.id_marca')
        ->join('nombre_productos', 'nombre_productos.id_nombre', 'clase_productos.id_nombre')
        ->join('vitola_productos', 'vitola_productos.id_vitola', 'clase_productos.id_vitola')
        ->join('capa_productos', 'capa_productos.id_capa', 'clase_productos.id_capa')
        ->join('tipo_empaques', 'tipo_empaques.id_tipo_empaque', 'clase_productos.id_tipo_empaque')
        ->select('po.item',
                'po.hon',
                'po.cantidad',
                'clase_productos.sampler',
                'marca_productos.marca',
                'nombre_productos.nombre',
                'vitola_productos.vitola',
                'capa_productos.capa',
                'tipo_empaques.tipo_empaque',
        DB::raw('(CASE
                        WHEN clase_productos.sampler = "si" THEN  clase_productos.descripcion_sampler
                        ELSE marca_productos.marca
                        END) AS descripcion'))
        ->where('po.item', 'LIKE', '%'.$this->b_item.'%')
        ->where('po.hon', 'LIKE', '%'.$this->b_orden.'%')
        ->orwhere('marca_productos.marca', 'LIKE', '%'.$this->b_marca.'%')
        ->orhaving('descripcion', 'LIKE', '%'.$this->b_marca.'%')
        ->where('nombre_productos.nombre', 'LIKE', '%'.$this->b_nombre.'%')
        ->where('vitola_productos.vitola', 'LIKE', '%'.$this->b_vitola.'%')
        ->where('capa_productos.capa', 'LIKE', '%'.$this->b_capa.'%')
        ->where('tipo_empaques.tipo_empaque', 'LIKE', '%'.$this->b_tipo_empaque.'%')
        ->orderBy('hon')->get();
        return view('livewire.importPO')->extends('principal')->section('content');
    }

    public function importPO(Request $request)
    {
        $hon= $request->file('select_file')->getClientOriginalName();
        Excel::import(new POimport($hon), $request->select_file);
        return redirect('/poimport');
    }

    public function deletePO(){

        if ($this->hondelete!=null) {
            DB::table('po')->where('hon', '=', $this->hondelete)->delete();
        $this->dispatchBrowserEvent('exito');
        }else{
            DB::table('po')->truncate();
        $this->dispatchBrowserEvent('exito');
        }
    }
}
