<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MaterialesCatalogo extends Model
{
    protected $table = "materiales_catalogo";

    protected $guarded = [];
    public $timestamps = false;
}
