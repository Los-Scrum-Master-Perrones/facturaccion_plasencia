@extends('principal')


@section('content')

<div style="text-align:center;">
    <img  src="pblanca.png"  id="animationlogo2" style="color:yellow;"/>
</div>
@endsection
