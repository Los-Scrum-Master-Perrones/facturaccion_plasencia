<div xmlns:wire="http://www.w3.org/1999/xhtml">
    {{-- The best athlete wants his opponent at his best. --}}
</div>
