<?php

namespace App\Http\Livewire;

use Livewire\Component;

class ProgramacionEmpaque extends Component
{
    public function render()
    {
        return view('livewire.programacion-empaque');
    }
}
