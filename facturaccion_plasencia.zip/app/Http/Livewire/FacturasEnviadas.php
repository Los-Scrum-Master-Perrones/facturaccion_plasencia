<?php

namespace App\Http\Livewire;

use Livewire\Component;

class FacturasEnviadas extends Component
{
    public function render()
    {
        return view('livewire.facturas-enviadas');
    }
}
