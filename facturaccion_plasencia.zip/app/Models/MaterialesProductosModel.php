<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MaterialesProductosModel extends Model
{
    protected $table = "materiales_productos";

    protected $guarded = [];
    public $timestamps = false;
}
